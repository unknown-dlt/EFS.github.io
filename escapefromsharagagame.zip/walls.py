from PIL import Image
import pygame

# Параметры игры
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 32

# Инициализация Pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# Загрузка изображения карты
map_image = Image.open("images/map.png")
map_pixels = map_image.load()
map_width, map_height = map_image.size

# Группа для стен
walls = pygame.sprite.Group()

# Класс для стен
class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((TILE_SIZE, TILE_SIZE))
        self.image.fill((139, 69, 19))  # Цвет стен
        self.rect = self.image.get_rect(topleft=(x, y))

# Генерация стен на основе изображения карты
for y in range(map_height):
    for x in range(map_width):
        # Получаем цвет пикселя
        pixel_color = map_pixels[x, y]

        # Если цвет чёрный (стена), создаём объект стены
        if pixel_color == (0, 0, 0):  # RGB цвет чёрного
            wall = Wall(x * TILE_SIZE, y * TILE_SIZE)
            walls.add(wall)

# Игровой цикл
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Рендеринг
    screen.fill((255, 255, 255))  # Белый фон
    walls.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
